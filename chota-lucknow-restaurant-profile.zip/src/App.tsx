import Preloader from "./components/Preloader";
import Nav from "./components/Nav";
import Hero from "./components/Hero";
import Ticker from "./components/Ticker";
import Intro from "./components/Intro";
import Pillars from "./components/Pillars";
import Story from "./components/Story";
import Signature from "./components/Signature";
import MenuSection from "./components/MenuSection";
import Gallery from "./components/Gallery";
import Reviews from "./components/Reviews";
import Reserve from "./components/Reserve";
import Footer from "./components/Footer";
import MobileBar from "./components/MobileBar";

export default function App() {
  return (
    <div className="min-h-screen bg-paper text-text">
      <Preloader />
      <Nav />
      <main>
        <Hero />
        <Ticker />
        <Intro />
        <Pillars />
        <Story />
        <Signature />
        <MenuSection />
        <Gallery />
        <Reviews />
        <Reserve />
      </main>
      <Footer />
      <MobileBar />
    </div>
  );
}
