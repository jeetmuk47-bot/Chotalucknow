export const BRAND = {
  name: "Chota Lucknow",
  urdu: "چھوٹا لکھنؤ",
  tagline: "A Royal Taste of Lucknow in Kolkata",
  phone: "+91 62931 12211",
  phoneTel: "+916293112211",
  address: "CW 43, Rabindra Nagar, Panchur Mauza, Kolkata, Maheshtala, West Bengal 700018",
  addressShort: "Rabindra Nagar, Panchur Mauza · Kolkata 700018",
  landmark: "Santoshpur Station Road area",
  hours: "Open Daily · 12 Noon – 12 Midnight",
  rating: "4.7",
  priceBand: "₹200–400 for one",
  instagramHandle: "@chotalucknowofficial",
  instagram: "https://instagram.com/chotalucknowofficial",
  maps: "https://www.google.com/maps/search/?api=1&query=Chota+Lucknow+Rabindra+Nagar+Kolkata",
  mapsEmbed: "https://www.google.com/maps?q=Chota+Lucknow+Rabindra+Nagar+Kolkata&output=embed",
};

export const HERO_SLIDES = [
  { src: "/images/hero-biryani.jpg", alt: "Copper handi of dum biryani" },
  { src: "/images/dastarkhwan.jpg", alt: "An Awadhi dastarkhwan laid for sharing" },
  { src: "/images/kebabs.jpg", alt: "Kebabs over charcoal" },
];

export const PILLARS = [
  {
    index: "01",
    title: "Biryani",
    note: "Dum-sealed handi · saffron · aged basmati",
    text: "Layered, sealed with dough and left to finish on dying embers — the way Awadh has cooked it for two centuries.",
    image: "/images/hero-biryani.jpg",
  },
  {
    index: "02",
    title: "Kebabs",
    note: "Charcoal · skewer · galouti",
    text: "Galouti that yields to the tongue, seekh kissed by embers, and marinades built overnight.",
    image: "/images/galouti-plate.jpg",
  },
  {
    index: "03",
    title: "Mughlai",
    note: "Slow gravies · cream · rose",
    text: "Kormas and rezalas simmered without hurry, finished with cashew, cream and the faintest breath of rose.",
    image: "/images/mughlai.jpg",
  },
  {
    index: "04",
    title: "Awadhi Table",
    note: "Sheermal · chai · the shared meal",
    text: "Breads, sides and small comforts that complete the dastarkhwan — food meant to be shared, not plated alone.",
    image: "/images/chai-sheermal.jpg",
  },
];

export const TIMELINE = [
  { year: "1856", title: "A Nawab arrives", text: "Wajid Ali Shah, the last Nawab of Awadh, reaches Calcutta and settles at Metiabruz on the Hooghly." },
  { year: "1860s", title: "A little Lucknow grows", text: "His court brings music, poetry, etiquette and kitchens. Metiabruz becomes known as Chhota Lucknow." },
  { year: "Since", title: "Kolkata's own biryani", text: "Awadhi dum cooking mingles with Bengal's produce — the potato enters the handi and a city's signature is born." },
  { year: "Today", title: "Chota Lucknow", text: "A neighbourhood table in Rabindra Nagar that carries the same conviction: patience, aroma, generosity." },
];

export const MENU = [
  {
    category: "Biryani",
    intro: "Cooked on dum in sealed handis. Served with burani raita.",
    items: [
      { name: "Lucknowi Chicken Biryani", desc: "Saffron, kewra, whole spices, slow-sealed" },
      { name: "Mutton Biryani", desc: "Aged basmati, tender mutton, ghee" },
      { name: "Egg & Aloo Biryani", desc: "The Kolkata inheritance — egg, potato, dum" },
      { name: "Subz Dum Biryani", desc: "Seasonal vegetables, mint, fried onion" },
    ],
  },
  {
    category: "Kebabs",
    intro: "From the sigri and the tawa. Served with mint chutney and lachha onion.",
    items: [
      { name: "Galouti Kebab", desc: "Fine-minced, spiced, melt-soft, on ulte tawa paratha" },
      { name: "Seekh Kebab", desc: "Charcoal-grilled skewers, onion, coriander" },
      { name: "Tangdi Kebab", desc: "Drumsticks marinated overnight in hung curd" },
      { name: "Paneer Tikka", desc: "Cottage cheese, capsicum, ajwain marinade" },
    ],
  },
  {
    category: "Mughlai",
    intro: "Rich, slow gravies made for tearing bread into.",
    items: [
      { name: "Chicken Rezala", desc: "Kolkata's white gravy — poppy seed, cashew, rose water" },
      { name: "Mutton Korma", desc: "Browned onion, yogurt, whole garam masala" },
      { name: "Shahi Paneer", desc: "Cashew and saffron gravy" },
      { name: "Mughlai Paratha", desc: "Egg and keema-stuffed, pan-crisped" },
    ],
  },
  {
    category: "Breads & Sides",
    intro: "Baked and griddled through the evening.",
    items: [
      { name: "Sheermal", desc: "Saffron milk bread of Lucknow" },
      { name: "Rumali Roti", desc: "Paper-thin, folded like a handkerchief" },
      { name: "Lachha Paratha", desc: "Layered whole wheat" },
      { name: "Burani Raita", desc: "Garlic yogurt, tempered cumin" },
    ],
  },
];

export const GALLERY = [
  { src: "/images/dastarkhwan.jpg", ratio: "aspect-[4/5]", caption: "The shared table" },
  { src: "/images/hands-dum.jpg", ratio: "aspect-[3/4]", caption: "Sealing the handi" },
  { src: "/images/interior.jpg", ratio: "aspect-[4/5]", caption: "The room" },
  { src: "/images/galouti-plate.jpg", ratio: "aspect-square", caption: "Galouti" },
  { src: "/images/kebabs.jpg", ratio: "aspect-[3/4]", caption: "Over charcoal" },
  { src: "/images/chai-sheermal.jpg", ratio: "aspect-[4/5]", caption: "Sheermal & chai" },
];

export const REVIEWS = [
  {
    name: "Ritika S.",
    text: "The biryani has that real Awadhi fragrance — subtle, never overpowering. A small trip to Lucknow without leaving Kolkata.",
  },
  {
    name: "Arjun M.",
    text: "Galouti kebabs were outstanding. Warm, unfussy room — perfect for a family dinner or a quiet date night.",
  },
  {
    name: "Sanya K.",
    text: "Mutton korma and sheermal, then chai. Generous portions, fair prices, and open till midnight. We'll be back.",
  },
];

export const TICKER = [
  "Biryani",
  "Kebabs",
  "Mughlai",
  "Awadhi",
  "Open till midnight",
  "Rabindra Nagar · Kolkata",
  "4.7 on Google",
  "Family dining",
];
