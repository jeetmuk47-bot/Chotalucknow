import { useEffect, useState } from "react";
import { BRAND } from "../data";

export default function Preloader() {
  const [out, setOut] = useState(false);
  const [gone, setGone] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setOut(true), 1600);
    const t2 = setTimeout(() => setGone(true), 2700);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  if (gone) return null;

  return (
    <div
      className={`fixed inset-0 z-[100] flex items-center justify-center bg-ink text-paper ${out ? "preloader-out" : ""}`}
      aria-hidden
    >
      <div className="flex flex-col items-center gap-6">
        <span className="font-urdu text-2xl text-gold-light/80">{BRAND.urdu}</span>
        <span className="font-serif text-3xl sm:text-4xl font-light tracking-[0.2em] uppercase">Chota Lucknow</span>
        <span className="preloader-line block h-px w-40 bg-gold" />
        <span className="label text-paper/50">Kolkata</span>
      </div>
    </div>
  );
}
