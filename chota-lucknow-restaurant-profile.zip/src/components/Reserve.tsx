import { useState } from "react";
import { BRAND } from "../data";
import { useOpenStatus, useRevealAll } from "../hooks";
import { ArrowRight, ArrowUpRight, Container, Index, Instagram, Navigation, Phone } from "./ui";

export default function Reserve() {
  const ref = useRevealAll<HTMLElement>();
  const status = useOpenStatus();
  const [sent, setSent] = useState(false);

  return (
    <section id="contact" ref={ref} className="bg-paper text-text py-24 sm:py-36 scroll-mt-16">
      <Container>
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-20">
          {/* Left: details */}
          <div className="lg:col-span-5">
            <div className="reveal">
              <Index n="07">Reservations & Contact</Index>
              <h2 className="display-md mt-6 text-4xl sm:text-5xl lg:text-6xl">
                Kolkata's <em className="italic font-normal">Nawabi</em> address.
              </h2>
            </div>

            <dl className="mt-12 divide-y divide-text/10 border-y border-text/10 reveal" style={{ transitionDelay: "120ms" }}>
              <div className="grid grid-cols-[6rem_1fr] gap-4 py-5">
                <dt className="label text-muted-2 pt-1">Address</dt>
                <dd>
                  <a href={BRAND.maps} target="_blank" rel="noreferrer" className="font-serif text-xl leading-snug link-line">
                    {BRAND.address}
                  </a>
                  <div className="mt-2 text-sm text-muted">{BRAND.landmark}</div>
                </dd>
              </div>
              <div className="grid grid-cols-[6rem_1fr] gap-4 py-5">
                <dt className="label text-muted-2 pt-1">Phone</dt>
                <dd>
                  <a href={`tel:${BRAND.phoneTel}`} className="font-serif text-xl link-line">
                    {BRAND.phone}
                  </a>
                  <div className="mt-2 text-sm text-muted">Reservations · orders · group enquiries</div>
                </dd>
              </div>
              <div className="grid grid-cols-[6rem_1fr] gap-4 py-5">
                <dt className="label text-muted-2 pt-1">Hours</dt>
                <dd>
                  <div className="font-serif text-xl">Every day, 12 noon – 12 midnight</div>
                  <div className="mt-2 inline-flex items-center gap-2 text-sm text-muted">
                    <span className={`h-1.5 w-1.5 rounded-full ${status.open ? "bg-emerald dot-live" : "bg-gold"}`} />
                    {status.label}
                  </div>
                </dd>
              </div>
              <div className="grid grid-cols-[6rem_1fr] gap-4 py-5">
                <dt className="label text-muted-2 pt-1">Social</dt>
                <dd>
                  <a href={BRAND.instagram} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 font-serif text-xl link-line">
                    <Instagram size={16} /> {BRAND.instagramHandle} <ArrowUpRight size={14} />
                  </a>
                </dd>
              </div>
            </dl>

            <div className="mt-8 flex flex-wrap gap-3 reveal" style={{ transitionDelay: "200ms" }}>
              <a href={`tel:${BRAND.phoneTel}`} className="btn btn-solid-dark">
                <Phone size={14} /> Call now
              </a>
              <a href={BRAND.maps} target="_blank" rel="noreferrer" className="btn btn-dark">
                <Navigation size={14} /> Directions
              </a>
            </div>
          </div>

          {/* Right: form */}
          <div className="lg:col-span-7">
            <div className="reveal bg-paper-2 p-7 sm:p-10 lg:p-12" style={{ transitionDelay: "180ms" }}>
              <div className="flex items-baseline justify-between">
                <h3 className="font-serif text-3xl font-light">Reserve a table</h3>
                <span className="label text-muted-2">Confirmed by call</span>
              </div>

              {sent ? (
                <div className="mt-10 border-t border-text/10 pt-10">
                  <p className="font-serif text-2xl font-light">Shukriya. We've noted your request.</p>
                  <p className="mt-3 text-sm text-muted">
                    Our team will call to confirm. For same-day tables, please phone{" "}
                    <a href={`tel:${BRAND.phoneTel}`} className="underline">
                      {BRAND.phone}
                    </a>
                    .
                  </p>
                </div>
              ) : (
                <form
                  className="mt-8 grid sm:grid-cols-2 gap-x-8 gap-y-6"
                  onSubmit={(e) => {
                    e.preventDefault();
                    setSent(true);
                  }}
                >
                  <label className="block">
                    <span className="label text-muted-2">Name</span>
                    <input required className="field mt-1" placeholder="Your name" />
                  </label>
                  <label className="block">
                    <span className="label text-muted-2">Phone</span>
                    <input required type="tel" className="field mt-1" placeholder="+91" />
                  </label>
                  <label className="block">
                    <span className="label text-muted-2">Date</span>
                    <input required type="date" className="field mt-1" />
                  </label>
                  <label className="block">
                    <span className="label text-muted-2">Time</span>
                    <input required type="time" min="12:00" max="23:30" className="field mt-1" />
                  </label>
                  <label className="block">
                    <span className="label text-muted-2">Guests</span>
                    <select className="field mt-1">
                      <option>2 guests</option>
                      <option>3 – 4 guests</option>
                      <option>5 – 6 guests</option>
                      <option>7 or more · group</option>
                    </select>
                  </label>
                  <label className="block">
                    <span className="label text-muted-2">Occasion (optional)</span>
                    <input className="field mt-1" placeholder="Birthday, family dinner…" />
                  </label>
                  <div className="sm:col-span-2 mt-2 flex flex-wrap items-center justify-between gap-4">
                    <p className="text-xs text-muted max-w-sm">
                      Requests are confirmed by phone. Walk-ins welcome, subject to availability.
                    </p>
                    <button type="submit" className="btn btn-solid-dark">
                      Request table <ArrowRight size={14} />
                    </button>
                  </div>
                </form>
              )}
            </div>

            {/* Map */}
            <div className="reveal mt-6 relative aspect-[16/9] overflow-hidden bg-paper-3" style={{ transitionDelay: "260ms" }}>
              <iframe
                title="Chota Lucknow on Google Maps"
                src={BRAND.mapsEmbed}
                className="absolute inset-0 h-full w-full"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                style={{ filter: "grayscale(1) sepia(0.25) contrast(0.95)" }}
              />
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
