import { BRAND, GALLERY } from "../data";
import { useRevealAll } from "../hooks";
import { ArrowUpRight, Container, Index, Instagram } from "./ui";

export default function Gallery() {
  const ref = useRevealAll<HTMLElement>();
  return (
    <section id="gallery" ref={ref} className="bg-paper-2 text-text py-24 sm:py-36 border-t border-text/10 scroll-mt-16 overflow-hidden">
      <Container>
        <div className="flex flex-wrap items-end justify-between gap-6 reveal">
          <div>
            <Index n="05">Gallery</Index>
            <h2 className="display-md mt-6 text-4xl sm:text-5xl lg:text-6xl">
              Inside the <em className="italic font-normal">room</em>
            </h2>
          </div>
          <a href={BRAND.instagram} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 label link-line">
            <Instagram size={14} /> {BRAND.instagramHandle} <ArrowUpRight size={12} />
          </a>
        </div>
      </Container>

      {/* Horizontal strip — bleeds off the right edge */}
      <div className="mt-14 pl-6 sm:pl-10 lg:pl-[max(4rem,calc((100vw-1440px)/2+4rem))]">
        <div className="hscroll pr-6">
          {GALLERY.map((g, i) => (
            <figure
              key={i}
              className="reveal w-[72vw] sm:w-[44vw] lg:w-[24vw] max-w-[420px]"
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className={`zoom-parent ${g.ratio} bg-paper-3`}>
                <img src={g.src} alt={g.caption} className="h-full w-full object-cover" loading="lazy" />
              </div>
              <figcaption className="mt-3 flex items-center justify-between label text-muted">
                <span>{g.caption}</span>
                <span className="opacity-60">0{i + 1}</span>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
