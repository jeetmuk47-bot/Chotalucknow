import { useEffect, useState } from "react";
import { BRAND, REVIEWS } from "../data";
import { useRevealAll } from "../hooks";
import { ArrowUpRight, Container, Index, Star } from "./ui";

export default function Reviews() {
  const ref = useRevealAll<HTMLElement>();
  const [i, setI] = useState(0);
  const [fade, setFade] = useState(true);

  useEffect(() => {
    const id = setInterval(() => {
      setFade(false);
      setTimeout(() => {
        setI((n) => (n + 1) % REVIEWS.length);
        setFade(true);
      }, 500);
    }, 6000);
    return () => clearInterval(id);
  }, []);

  const r = REVIEWS[i];

  return (
    <section id="reviews" ref={ref} className="bg-ink text-paper py-24 sm:py-36 scroll-mt-16">
      <Container>
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-20">
          <div className="lg:col-span-4 reveal">
            <Index n="06" className="text-paper/70">
              Guests
            </Index>
            <div className="mt-10 flex items-end gap-5">
              <span className="display text-8xl sm:text-9xl text-paper">{BRAND.rating}</span>
              <div className="pb-3">
                <div className="flex gap-1 text-gold-light">
                  {Array.from({ length: 5 }).map((_, k) => (
                    <Star key={k} size={12} />
                  ))}
                </div>
                <div className="label mt-2 text-paper/60">on Google</div>
              </div>
            </div>
            <a
              href={BRAND.maps}
              target="_blank"
              rel="noreferrer"
              className="mt-8 inline-flex items-center gap-2 label link-line text-paper/80"
            >
              Read all reviews <ArrowUpRight size={12} />
            </a>
          </div>

          <div className="lg:col-span-8 reveal" style={{ transitionDelay: "150ms" }}>
            <div className={`transition-all duration-500 ${fade ? "opacity-100 translate-y-0" : "opacity-0 translate-y-3"}`}>
              <blockquote className="display-md text-3xl sm:text-4xl lg:text-5xl xl:text-6xl leading-[1.1] max-w-4xl">
                “{r.text}”
              </blockquote>
              <div className="mt-8 flex items-center gap-4">
                <span className="hairline w-10 bg-paper" />
                <span className="label text-paper/70">{r.name}</span>
              </div>
            </div>

            <div className="mt-14 flex items-center gap-3">
              {REVIEWS.map((_, k) => (
                <button
                  key={k}
                  aria-label={`Review ${k + 1}`}
                  onClick={() => {
                    setFade(false);
                    setTimeout(() => {
                      setI(k);
                      setFade(true);
                    }, 300);
                  }}
                  className={`h-px transition-all duration-500 ${k === i ? "w-12 bg-paper" : "w-6 bg-paper/30 hover:bg-paper/60"}`}
                />
              ))}
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
