import { TIMELINE } from "../data";
import { useRevealAll } from "../hooks";
import { Container, Index } from "./ui";

export default function Story() {
  const ref = useRevealAll<HTMLElement>();
  return (
    <section id="story" ref={ref} className="bg-espresso text-paper py-24 sm:py-36 scroll-mt-16">
      <Container>
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-20">
          {/* Sticky heading */}
          <div className="lg:col-span-5 lg:sticky lg:top-28 self-start">
            <div className="reveal">
              <Index n="03" className="text-paper/70">
                Our Story
              </Index>
              <h2 className="display-md mt-6 text-4xl sm:text-5xl lg:text-6xl xl:text-7xl">
                From the soul of Lucknow to the heart of Kolkata.
              </h2>
              <p className="mt-8 max-w-md text-[15px] leading-[1.8] text-paper/65">
                The name is not decoration. Kolkata has been home to a little Lucknow since 1856, when the last Nawab
                of Awadh crossed the country and rebuilt his world along the Hooghly — its music, its manners and,
                above all, its kitchens.
              </p>
            </div>
            <div className="img-reveal mt-12 aspect-[4/3] overflow-hidden">
              <img src="/images/hands-dum.jpg" alt="Sealing the handi with dough" className="h-full w-full object-cover" />
            </div>
          </div>

          {/* Timeline */}
          <ol className="lg:col-span-7 lg:pt-4">
            {TIMELINE.map((t, i) => (
              <li
                key={t.year}
                className="reveal grid grid-cols-[6rem_1fr] sm:grid-cols-[9rem_1fr] gap-6 border-t border-paper/15 py-10 first:border-t-0 lg:first:border-t"
                style={{ transitionDelay: `${i * 90}ms` }}
              >
                <div className="font-serif text-3xl sm:text-4xl font-light text-gold-light">{t.year}</div>
                <div>
                  <h3 className="font-serif text-2xl sm:text-3xl font-light">{t.title}</h3>
                  <p className="mt-3 max-w-lg text-[15px] leading-[1.8] text-paper/65">{t.text}</p>
                </div>
              </li>
            ))}
            <li className="reveal border-t border-paper/15 pt-10">
              <blockquote className="font-serif text-2xl sm:text-3xl lg:text-4xl font-light italic leading-snug max-w-2xl">
                “Where every dastarkhwan feels royal — and every table feels like home.”
              </blockquote>
              <div className="mt-8 flex flex-wrap gap-4">
                <a href="#contact" className="btn btn-light">
                  Reserve a Table
                </a>
                <a href="#menu" className="btn btn-light">
                  See the Menu
                </a>
              </div>
            </li>
          </ol>
        </div>
      </Container>
    </section>
  );
}
