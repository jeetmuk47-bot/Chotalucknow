import { BRAND } from "../data";
import { ArrowUpRight, Container, Instagram } from "./ui";

export default function Footer() {
  return (
    <footer className="bg-ink text-paper pt-20 pb-28 sm:pb-10 overflow-hidden">
      <Container>
        <div className="grid md:grid-cols-12 gap-10 border-b border-paper/10 pb-14">
          <div className="md:col-span-5">
            <div className="font-urdu text-2xl text-gold-light/80">{BRAND.urdu}</div>
            <p className="mt-5 max-w-sm font-serif text-xl font-light leading-snug text-paper/85">
              A Lucknow-inspired dining table in Rabindra Nagar, Kolkata. Biryani, kebabs and Mughlai classics —
              cooked to order, served warm, open till midnight.
            </p>
          </div>

          <div className="md:col-span-2">
            <div className="label text-paper/50">Explore</div>
            <ul className="mt-5 space-y-2.5 text-sm">
              {[
                ["Menu", "#menu"],
                ["Gallery", "#gallery"],
                ["Our Story", "#story"],
                ["Reviews", "#reviews"],
                ["Contact", "#contact"],
              ].map(([l, h]) => (
                <li key={h}>
                  <a href={h} className="link-line text-paper/80 hover:text-paper">
                    {l}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-3">
            <div className="label text-paper/50">Visit</div>
            <p className="mt-5 text-sm leading-relaxed text-paper/80">{BRAND.address}</p>
            <p className="mt-3 text-sm text-paper/80">{BRAND.hours}</p>
          </div>

          <div className="md:col-span-2">
            <div className="label text-paper/50">Connect</div>
            <ul className="mt-5 space-y-2.5 text-sm">
              <li>
                <a href={`tel:${BRAND.phoneTel}`} className="link-line text-paper/80">
                  {BRAND.phone}
                </a>
              </li>
              <li>
                <a href={BRAND.instagram} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 link-line text-paper/80">
                  <Instagram size={13} /> Instagram <ArrowUpRight size={11} />
                </a>
              </li>
              <li>
                <a href={BRAND.maps} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 link-line text-paper/80">
                  Google Maps <ArrowUpRight size={11} />
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Giant wordmark */}
        <div className="pt-10 select-none">
          <div className="display whitespace-nowrap text-[13.5vw] leading-none tracking-[-0.02em] text-paper/90">
            Chota Lucknow
          </div>
        </div>

        <div className="mt-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 label text-paper/40">
          <span>© {new Date().getFullYear()} Chota Lucknow · Kolkata</span>
          <span>A royal taste of Lucknow in Kolkata</span>
        </div>
      </Container>
    </footer>
  );
}
