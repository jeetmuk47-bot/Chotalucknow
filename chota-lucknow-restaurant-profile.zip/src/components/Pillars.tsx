import { useState } from "react";
import { PILLARS } from "../data";
import { useRevealAll } from "../hooks";
import { ArrowUpRight, Container, Index } from "./ui";

export default function Pillars() {
  const ref = useRevealAll<HTMLElement>();
  const [active, setActive] = useState(0);

  return (
    <section ref={ref} className="bg-paper-2 text-text py-24 sm:py-36 border-t border-text/10">
      <Container>
        <div className="flex flex-wrap items-end justify-between gap-6 reveal">
          <div>
            <Index n="02">Signature Experiences</Index>
            <h2 className="display-md mt-6 text-4xl sm:text-5xl lg:text-6xl">
              Four pillars of <em className="italic font-normal">the dastarkhwan</em>
            </h2>
          </div>
          <p className="max-w-xs text-sm leading-relaxed text-muted">
            Hover or tap a course. Each belongs to a tradition older than the city that adopted it.
          </p>
        </div>

        <div className="mt-16 grid lg:grid-cols-12 gap-10 lg:gap-16 items-start">
          {/* List */}
          <ul className="lg:col-span-7 border-t border-text/15 reveal" style={{ transitionDelay: "120ms" }}>
            {PILLARS.map((p, i) => (
              <li key={p.title}>
                <button
                  onMouseEnter={() => setActive(i)}
                  onFocus={() => setActive(i)}
                  onClick={() => setActive(i)}
                  className={`pillar-row group w-full text-left border-b border-text/15 py-7 sm:py-9 flex items-baseline gap-6 sm:gap-10 ${
                    active === i ? "text-text" : "text-text/55"
                  }`}
                >
                  <span className="label w-8 shrink-0 opacity-60">{p.index}</span>
                  <span className="flex-1">
                    <span className="display-md block text-4xl sm:text-5xl lg:text-6xl">{p.title}</span>
                    <span
                      className={`block overflow-hidden transition-[max-height,opacity] duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] ${
                        active === i ? "max-h-40 opacity-100" : "max-h-0 opacity-0"
                      }`}
                    >
                      <span className="label block mt-4 text-gold">{p.note}</span>
                      <span className="block mt-3 max-w-md text-sm leading-relaxed text-muted">{p.text}</span>
                    </span>
                  </span>
                  <ArrowUpRight
                    size={22}
                    className={`shrink-0 transition-all duration-500 ${active === i ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-2"}`}
                  />
                </button>
              </li>
            ))}
          </ul>

          {/* Image stage */}
          <div className="lg:col-span-5 lg:sticky lg:top-28 reveal" style={{ transitionDelay: "240ms" }}>
            <div className="relative aspect-[4/5] overflow-hidden bg-paper-3">
              {PILLARS.map((p, i) => (
                <img
                  key={p.image + i}
                  src={p.image}
                  alt={p.title}
                  className={`absolute inset-0 h-full w-full object-cover transition-all duration-[1100ms] ease-[cubic-bezier(0.16,1,0.3,1)] ${
                    active === i ? "opacity-100 scale-100" : "opacity-0 scale-105"
                  }`}
                />
              ))}
            </div>
            <div className="mt-4 flex items-center justify-between label text-muted">
              <span>{PILLARS[active].title}</span>
              <span>
                {PILLARS[active].index} / 0{PILLARS.length}
              </span>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
