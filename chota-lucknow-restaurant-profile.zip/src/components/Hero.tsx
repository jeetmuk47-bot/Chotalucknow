import { useEffect, useState } from "react";
import { BRAND, HERO_SLIDES } from "../data";
import { ArrowDown, Container, Star } from "./ui";

export default function Hero() {
  const [i, setI] = useState(0);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setReady(true), 1900);
    const id = setInterval(() => setI((n) => (n + 1) % HERO_SLIDES.length), 6500);
    return () => {
      clearTimeout(t);
      clearInterval(id);
    };
  }, []);

  return (
    <section id="top" className="relative h-[100svh] min-h-[640px] w-full overflow-hidden bg-ink text-paper grain">
      {/* Slideshow */}
      {HERO_SLIDES.map((s, idx) => (
        <div key={s.src} className={`slide ${idx === i ? "active" : ""}`}>
          <img src={s.src} alt={s.alt} className="h-full w-full object-cover" loading={idx === 0 ? "eager" : "lazy"} />
        </div>
      ))}
      <div className="absolute inset-0 bg-gradient-to-b from-ink/50 via-ink/10 to-ink/70" />

      {/* Content */}
      <Container className="relative z-10 flex h-full flex-col justify-end pb-10 sm:pb-14">
        <div className={`transition-all duration-[1400ms] ease-[cubic-bezier(0.16,1,0.3,1)] ${ready ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          <div className="label mb-6 flex items-center gap-4 text-paper/70">
            <span>Awadhi · Mughlai · Biryani</span>
            <span className="hairline w-10 bg-paper" />
            <span>Kolkata</span>
          </div>

          <h1 className="display text-[15vw] sm:text-[11vw] lg:text-[9vw] xl:text-[8.2rem] max-w-[14ch]">
            A Taste of
            <br />
            <em className="not-italic font-normal italic">Lucknow</em>
            <span className="font-light">, in Kolkata.</span>
          </h1>
        </div>

        <div
          className={`mt-10 grid gap-8 sm:grid-cols-3 sm:items-end transition-all duration-[1400ms] delay-200 ease-[cubic-bezier(0.16,1,0.3,1)] ${
            ready ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        >
          <p className="font-serif text-lg sm:text-xl leading-snug text-paper/85 max-w-sm">
            Fragrant biryanis. Charred kebabs. Rich Mughlai favourites. A dastarkhwan made for food, family and
            long evenings.
          </p>

          <div className="flex flex-wrap gap-3 sm:justify-center">
            <a href="#menu" className="btn btn-light">
              Explore the Menu
            </a>
            <a href="#contact" className="btn btn-light">
              Reserve a Table
            </a>
          </div>

          <div className="flex sm:justify-end">
            <a
              href={BRAND.maps}
              target="_blank"
              rel="noreferrer"
              className="group inline-flex items-center gap-3 border-b border-paper/30 pb-2 hover:border-paper transition"
            >
              <span className="flex gap-0.5 text-gold-light">
                {Array.from({ length: 5 }).map((_, k) => (
                  <Star key={k} size={10} />
                ))}
              </span>
              <span className="label">
                <span className="font-serif text-base tracking-normal normal-case mr-1">{BRAND.rating}</span> on Google
              </span>
            </a>
          </div>
        </div>

        {/* Slide index + scroll */}
        <div className="mt-8 flex items-center justify-between border-t border-paper/15 pt-5 label text-paper/60">
          <div className="flex items-center gap-3">
            {HERO_SLIDES.map((_, k) => (
              <button
                key={k}
                onClick={() => setI(k)}
                aria-label={`Slide ${k + 1}`}
                className={`h-px transition-all duration-500 ${k === i ? "w-10 bg-paper" : "w-5 bg-paper/40"}`}
              />
            ))}
            <span className="ml-2">
              0{i + 1} / 0{HERO_SLIDES.length}
            </span>
          </div>
          <span className="hidden sm:inline-flex items-center gap-2">
            Scroll <ArrowDown size={12} />
          </span>
        </div>
      </Container>
    </section>
  );
}
