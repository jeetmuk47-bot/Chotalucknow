import { useEffect, useState } from "react";
import { BRAND } from "../data";
import { useOpenStatus, useScrolled } from "../hooks";
import { ArrowUpRight, Container, Instagram, Phone } from "./ui";

const LINKS = [
  { label: "Menu", href: "#menu" },
  { label: "Gallery", href: "#gallery" },
  { label: "Our Story", href: "#story" },
  { label: "Reviews", href: "#reviews" },
  { label: "Contact", href: "#contact" },
];

export default function Nav() {
  const scrolled = useScrolled(60);
  const [open, setOpen] = useState(false);
  const status = useOpenStatus();

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const dark = !scrolled && !open; // over the hero photo

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-[background-color,color,border-color,padding] duration-700 ${
          scrolled && !open
            ? "bg-paper/85 text-text backdrop-blur-md border-b border-text/10 py-3"
            : "bg-transparent text-paper py-5"
        }`}
      >
        <Container className="flex items-center justify-between">
          {/* Wordmark */}
          <a href="#top" className="group flex items-baseline gap-3" onClick={() => setOpen(false)}>
            <span className="font-serif text-xl sm:text-2xl font-light uppercase tracking-[0.22em]">Chota Lucknow</span>
            <span className={`font-urdu hidden md:inline text-sm transition-opacity ${dark ? "text-gold-light/80" : "text-gold"}`}>
              {BRAND.urdu}
            </span>
          </a>

          {/* Desktop links */}
          <nav className="hidden lg:flex items-center gap-10">
            {LINKS.map((l) => (
              <a key={l.href} href={l.href} className="label link-line">
                {l.label}
              </a>
            ))}
          </nav>

          {/* Right cluster */}
          <div className="flex items-center gap-5">
            {/* Live status — the signature flourish */}
            <div className="hidden md:flex items-center gap-2.5 label">
              <span className={`h-1.5 w-1.5 rounded-full ${status.open ? "bg-emerald dot-live" : "bg-gold"}`} />
              <span className="opacity-80">{status.label}</span>
            </div>
            <a
              href="#contact"
              className={`hidden sm:inline-flex btn ${dark ? "btn-light" : "btn-dark"} !py-3 !px-6`}
            >
              Reserve
            </a>
            <button
              aria-label="Open menu"
              onClick={() => setOpen((o) => !o)}
              className="lg:hidden relative h-10 w-10 flex items-center justify-center"
            >
              <span className={`absolute h-px w-6 bg-current transition-all duration-500 ${open ? "rotate-45" : "-translate-y-1.5"}`} />
              <span className={`absolute h-px w-6 bg-current transition-all duration-500 ${open ? "-rotate-45" : "translate-y-1.5"}`} />
            </button>
          </div>
        </Container>
      </header>

      {/* Overlay menu (mobile / tablet) */}
      <div
        className={`fixed inset-0 z-40 bg-ink text-paper transition-[clip-path] duration-700 ease-[cubic-bezier(0.76,0,0.24,1)] ${
          open ? "[clip-path:inset(0_0_0_0)]" : "[clip-path:inset(0_0_100%_0)] pointer-events-none"
        }`}
      >
        <Container className="flex h-full flex-col justify-between pt-28 pb-10">
          <nav className="flex flex-col gap-1">
            {LINKS.map((l, i) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="group flex items-baseline justify-between border-b border-paper/10 py-4"
              >
                <span className="font-serif text-4xl sm:text-5xl font-light">{l.label}</span>
                <span className="label opacity-40 group-hover:opacity-100 transition">0{i + 1}</span>
              </a>
            ))}
          </nav>
          <div className="grid sm:grid-cols-2 gap-8">
            <div className="space-y-3">
              <div className="label text-paper/50">Visit</div>
              <p className="font-serif text-xl leading-snug text-paper/90">{BRAND.address}</p>
              <p className="label text-gold-light">{BRAND.hours}</p>
            </div>
            <div className="flex flex-col gap-3 sm:items-end">
              <a href={`tel:${BRAND.phoneTel}`} className="inline-flex items-center gap-3 font-serif text-2xl">
                <Phone size={18} /> {BRAND.phone}
              </a>
              <a href={BRAND.instagram} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 label text-paper/70">
                <Instagram size={14} /> {BRAND.instagramHandle} <ArrowUpRight size={12} />
              </a>
            </div>
          </div>
        </Container>
      </div>
    </>
  );
}
