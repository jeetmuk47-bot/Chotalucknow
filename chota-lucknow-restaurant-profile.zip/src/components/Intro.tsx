import { BRAND } from "../data";
import { useRevealAll } from "../hooks";
import { Container, Index } from "./ui";

export default function Intro() {
  const ref = useRevealAll<HTMLElement>();
  return (
    <section ref={ref} className="bg-paper text-text py-24 sm:py-36">
      <Container>
        <div className="grid lg:grid-cols-12 gap-10 lg:gap-16">
          <div className="lg:col-span-3 reveal">
            <Index n="01">Welcome</Index>
            <div className="font-urdu mt-8 text-3xl text-gold leading-loose">{BRAND.urdu}</div>
          </div>

          <div className="lg:col-span-9">
            <h2 className="display-md text-4xl sm:text-5xl lg:text-6xl xl:text-7xl max-w-[18ch] reveal">
              The Nawabi soul of Lucknow, served with the warmth of a Kolkata neighbourhood table.
            </h2>

            <div className="mt-12 grid sm:grid-cols-2 gap-10 max-w-3xl">
              <p className="reveal text-[15px] leading-[1.8] text-muted" style={{ transitionDelay: "120ms" }}>
                Chota Lucknow brings the aroma and celebratory spirit of Lucknow-inspired dining to Rabindra Nagar.
                From dum biryani and flavour-packed kebabs to slow Mughlai gravies, our table is designed around food
                meant to be shared, remembered and returned to.
              </p>
              <p className="reveal text-[15px] leading-[1.8] text-muted" style={{ transitionDelay: "220ms" }}>
                Open every day from noon to midnight, priced for the neighbourhood, and cooked with the patience the
                cuisine demands. Come as a family, a table of friends, or two people with a craving.
              </p>
            </div>

            <dl className="mt-14 grid grid-cols-2 sm:grid-cols-4 gap-y-8 border-t border-text/10 pt-8 reveal" style={{ transitionDelay: "300ms" }}>
              {[
                ["Rating", `${BRAND.rating} / 5 on Google`],
                ["Hours", "Daily, 12 PM – 12 AM"],
                ["For one", BRAND.priceBand],
                ["Where", "Rabindra Nagar"],
              ].map(([k, v]) => (
                <div key={k}>
                  <dt className="label text-muted-2">{k}</dt>
                  <dd className="mt-2 font-serif text-xl">{v}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </Container>
    </section>
  );
}
