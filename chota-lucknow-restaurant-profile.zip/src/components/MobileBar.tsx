import { BRAND } from "../data";
import { Fork, Navigation, Phone } from "./ui";

export default function MobileBar() {
  return (
    <div className="fixed bottom-0 inset-x-0 z-40 sm:hidden bg-paper/95 text-text backdrop-blur-md border-t border-text/10">
      <div className="grid grid-cols-3 divide-x divide-text/10">
        <a href={`tel:${BRAND.phoneTel}`} className="flex flex-col items-center justify-center py-3 gap-1">
          <Phone size={16} />
          <span className="label !text-[0.58rem]">Call</span>
        </a>
        <a href={BRAND.maps} target="_blank" rel="noreferrer" className="flex flex-col items-center justify-center py-3 gap-1">
          <Navigation size={16} />
          <span className="label !text-[0.58rem]">Directions</span>
        </a>
        <a href="#menu" className="flex flex-col items-center justify-center py-3 gap-1">
          <Fork size={16} />
          <span className="label !text-[0.58rem]">Menu</span>
        </a>
      </div>
    </div>
  );
}
