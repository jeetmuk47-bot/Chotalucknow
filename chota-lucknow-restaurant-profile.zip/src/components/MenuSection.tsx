import { useState } from "react";
import { BRAND, MENU } from "../data";
import { useRevealAll } from "../hooks";
import { Container, Index, Phone } from "./ui";

export default function MenuSection() {
  const ref = useRevealAll<HTMLElement>();
  const [active, setActive] = useState(0);
  const cat = MENU[active];

  return (
    <section id="menu" ref={ref} className="bg-paper text-text py-24 sm:py-36 scroll-mt-16">
      <Container>
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-20">
          {/* Sticky sidebar */}
          <aside className="lg:col-span-4 lg:sticky lg:top-28 self-start reveal">
            <Index n="04">The Menu</Index>
            <h2 className="display-md mt-6 text-4xl sm:text-5xl lg:text-6xl">
              A royal <em className="italic font-normal">dastarkhwan</em>
            </h2>
            <p className="mt-6 max-w-sm text-sm leading-relaxed text-muted">
              A selection of house favourites. Everything is cooked to order; the full menu with today's prices is
              available at the table or by phone.
            </p>

            <nav className="mt-10 flex lg:flex-col gap-x-6 gap-y-3 overflow-x-auto no-scrollbar">
              {MENU.map((m, i) => (
                <button
                  key={m.category}
                  onClick={() => setActive(i)}
                  className={`group flex items-center gap-4 whitespace-nowrap py-1 text-left transition ${
                    active === i ? "text-text" : "text-muted-2 hover:text-text"
                  }`}
                >
                  <span className={`hairline transition-all duration-500 ${active === i ? "w-8 opacity-100" : "w-0 opacity-0"}`} />
                  <span className="font-serif text-2xl font-light">{m.category}</span>
                </button>
              ))}
            </nav>

            <div className="mt-10 border-t border-text/10 pt-6 flex flex-wrap items-center gap-x-8 gap-y-3 label text-muted">
              <span>{BRAND.priceBand}</span>
              <span>Veg & non-veg</span>
            </div>
          </aside>

          {/* Items */}
          <div className="lg:col-span-8">
            <div key={cat.category} className="reveal is-visible" style={{ animation: "fadeUp 0.9s cubic-bezier(0.16,1,0.3,1) both" }}>
              <div className="flex items-baseline justify-between border-b border-text/15 pb-4">
                <h3 className="font-serif text-3xl sm:text-4xl font-light">{cat.category}</h3>
                <span className="label text-muted-2">
                  0{active + 1} / 0{MENU.length}
                </span>
              </div>
              <p className="mt-4 font-serif italic text-lg text-muted">{cat.intro}</p>

              <ul className="mt-6">
                {cat.items.map((it, i) => (
                  <li
                    key={it.name}
                    className="group grid grid-cols-[2.5rem_1fr] sm:grid-cols-[3.5rem_1fr] gap-4 border-b border-text/10 py-6 transition-colors hover:bg-paper-2/70 -mx-3 px-3"
                    style={{ animation: `fadeUp 0.9s cubic-bezier(0.16,1,0.3,1) ${i * 70}ms both` }}
                  >
                    <span className="label pt-2 text-muted-2">0{i + 1}</span>
                    <div>
                      <div className="font-serif text-2xl sm:text-[1.7rem] font-light leading-tight">{it.name}</div>
                      <div className="mt-1.5 text-sm text-muted">{it.desc}</div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-10 flex flex-wrap items-center gap-6">
              <a href={`tel:${BRAND.phoneTel}`} className="btn btn-dark">
                <Phone size={14} /> Call for today's menu
              </a>
              <span className="label text-muted-2">Group & party orders welcome</span>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
