import { TICKER } from "../data";

export default function Ticker() {
  const items = [...TICKER, ...TICKER];
  return (
    <div className="marquee overflow-hidden border-y border-text/10 bg-paper py-4 text-text">
      <div className="marquee-track">
        {items.map((t, i) => (
          <span key={i} className="flex items-center gap-8 pr-8 label">
            <span>{t}</span>
            <span className="h-1 w-1 rounded-full bg-gold" />
          </span>
        ))}
      </div>
    </div>
  );
}
