import type { ReactNode } from "react";

export function Label({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <span className={`label ${className}`}>{children}</span>;
}

/** Section index label — e.g. "01 — Welcome" */
export function Index({ n, children, className = "" }: { n: string; children: ReactNode; className?: string }) {
  return (
    <div className={`label flex items-center gap-4 ${className}`}>
      <span className="opacity-60">{n}</span>
      <span className="hairline w-8" />
      <span>{children}</span>
    </div>
  );
}

export function Container({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`mx-auto w-full max-w-[1440px] px-6 sm:px-10 lg:px-16 ${className}`}>{children}</div>;
}

/* Icons (inline, stroke-based, consistent 1.5 weight) */
type IconProps = { size?: number; className?: string };
const base = (size: number, className: string) => ({
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.5,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  className,
  "aria-hidden": true,
});

export const ArrowRight = ({ size = 16, className = "" }: IconProps) => (
  <svg {...base(size, className)}>
    <path d="M5 12h14M13 6l6 6-6 6" />
  </svg>
);
export const ArrowDown = ({ size = 16, className = "" }: IconProps) => (
  <svg {...base(size, className)}>
    <path d="M12 5v14M6 13l6 6 6-6" />
  </svg>
);
export const ArrowUpRight = ({ size = 16, className = "" }: IconProps) => (
  <svg {...base(size, className)}>
    <path d="M7 17 17 7M8 7h9v9" />
  </svg>
);
export const Phone = ({ size = 16, className = "" }: IconProps) => (
  <svg {...base(size, className)}>
    <path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2" />
  </svg>
);
export const Pin = ({ size = 16, className = "" }: IconProps) => (
  <svg {...base(size, className)}>
    <path d="M12 21s-6-5.5-6-11a6 6 0 1 1 12 0c0 5.5-6 11-6 11Z" />
    <circle cx="12" cy="10" r="2.2" />
  </svg>
);
export const Clock = ({ size = 16, className = "" }: IconProps) => (
  <svg {...base(size, className)}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v5l3 2" />
  </svg>
);
export const Instagram = ({ size = 16, className = "" }: IconProps) => (
  <svg {...base(size, className)}>
    <rect x="3.5" y="3.5" width="17" height="17" rx="4.5" />
    <circle cx="12" cy="12" r="3.8" />
    <circle cx="17.2" cy="6.8" r="0.8" fill="currentColor" stroke="none" />
  </svg>
);
export const Star = ({ size = 12, className = "" }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
    <path d="m12 2 2.9 6.6 7.1.7-5.4 4.8 1.6 7L12 17.4 5.8 21l1.6-7L2 9.3l7.1-.7L12 2Z" />
  </svg>
);
export const Menu = ({ size = 16, className = "" }: IconProps) => (
  <svg {...base(size, className)}>
    <path d="M4 12h16M4 6h16M4 18h16" />
  </svg>
);
export const Fork = ({ size = 16, className = "" }: IconProps) => (
  <svg {...base(size, className)}>
    <path d="M7 3v7a3 3 0 0 0 6 0V3M10 3v18M17 3c-2 2-2 6-2 8v10M17 3v18" />
  </svg>
);
export const Navigation = ({ size = 16, className = "" }: IconProps) => (
  <svg {...base(size, className)}>
    <path d="m3 11 18-8-8 18-2-8-8-2Z" />
  </svg>
);
