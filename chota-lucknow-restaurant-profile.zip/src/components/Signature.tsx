import { useParallax, useRevealAll } from "../hooks";
import { Container, Label } from "./ui";

export default function Signature() {
  const img = useParallax<HTMLImageElement>(0.18);
  const ref = useRevealAll<HTMLElement>();
  return (
    <section ref={ref} className="relative h-[90svh] min-h-[560px] overflow-hidden bg-ink text-paper grain">
      <img
        ref={img}
        src="/images/hero-biryani.jpg"
        alt="Signature handi biryani"
        className="absolute inset-0 h-full w-full object-cover will-change-transform"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/20 to-ink/30" />

      <Container className="relative z-10 flex h-full flex-col justify-end pb-12 sm:pb-16">
        <div className="grid lg:grid-cols-12 gap-8 items-end">
          <div className="lg:col-span-8 reveal">
            <Label className="text-gold-light">House signature</Label>
            <h2 className="display mt-5 text-5xl sm:text-6xl lg:text-7xl xl:text-8xl">
              The handi <em className="italic font-normal">biryani</em>
            </h2>
          </div>
          <div className="lg:col-span-4 reveal" style={{ transitionDelay: "150ms" }}>
            <p className="text-[15px] leading-[1.8] text-paper/75 max-w-sm">
              Aged basmati, saffron milk and whole spices sealed under a ring of dough and finished on dying embers —
              so every grain holds the memory of the fire. Served with burani raita.
            </p>
            <ul className="mt-6 flex flex-wrap gap-x-6 gap-y-2 label text-paper/60">
              <li>Dum-cooked</li>
              <li>Kewra & rose</li>
              <li>Made to order</li>
            </ul>
          </div>
        </div>
      </Container>
    </section>
  );
}
